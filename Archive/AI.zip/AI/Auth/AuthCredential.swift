import Foundation

enum AuthCredential: Codable, Equatable {
    case apiKey(String)
    case oauth(refresh: String, access: String, expiresAt: Date, endpoint: String?)

    private enum CodingKeys: String, CodingKey {
        case type, refresh, access, expiresAt, key, endpoint
    }

    private enum CredentialType: String, Codable {
        case api
        case oauth
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let type = try container.decode(CredentialType.self, forKey: .type)
        switch type {
        case .api:
            self = .apiKey(try container.decode(String.self, forKey: .key))
        case .oauth:
            let refresh = try container.decode(String.self, forKey: .refresh)
            let access = try container.decode(String.self, forKey: .access)
            let expiresAt = try container.decode(Date.self, forKey: .expiresAt)
            let endpoint = try container.decodeIfPresent(String.self, forKey: .endpoint)
            self = .oauth(refresh: refresh, access: access, expiresAt: expiresAt, endpoint: endpoint)
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .apiKey(let key):
            try container.encode(CredentialType.api, forKey: .type)
            try container.encode(key, forKey: .key)
        case .oauth(let refresh, let access, let expiresAt, let endpoint):
            try container.encode(CredentialType.oauth, forKey: .type)
            try container.encode(refresh, forKey: .refresh)
            try container.encode(access, forKey: .access)
            try container.encode(expiresAt, forKey: .expiresAt)
            try container.encodeIfPresent(endpoint, forKey: .endpoint)
        }
    }
}
