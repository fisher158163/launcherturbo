import Foundation

protocol AuthStoring {
    func credential(for provider: LLMProviderID) -> AuthCredential?
    func save(_ credential: AuthCredential, for provider: LLMProviderID) throws
    func removeCredential(for provider: LLMProviderID) throws
}

final class FileAuthStore: AuthStoring {
    private let fileURL: URL
    private var cache: [String: AuthCredential] = [:]
    private let queue = DispatchQueue(label: "ai.auth.store", qos: .utility)

    init(directoryName: String = "ai") {
        let baseURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let directory = baseURL.appendingPathComponent("LaunchNext", isDirectory: true)
            .appendingPathComponent(directoryName, isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        self.fileURL = directory.appendingPathComponent("auth.json")
        loadCache()
    }

    func credential(for provider: LLMProviderID) -> AuthCredential? {
        queue.sync {
            cache[provider.rawValue]
        }
    }

    func save(_ credential: AuthCredential, for provider: LLMProviderID) throws {
        try queue.sync {
            cache[provider.rawValue] = credential
            try persist()
        }
    }

    func removeCredential(for provider: LLMProviderID) throws {
        try queue.sync {
            cache.removeValue(forKey: provider.rawValue)
            try persist()
        }
    }

    private func loadCache() {
        queue.sync {
            guard let data = try? Data(contentsOf: fileURL) else {
                cache = [:]
                return
            }
            cache = (try? JSONDecoder().decode([String: AuthCredential].self, from: data)) ?? [:]
        }
    }

    private func persist() throws {
        let data = try JSONEncoder().encode(cache)
        try data.write(to: fileURL, options: [.atomic])
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: fileURL.path)
    }
}
