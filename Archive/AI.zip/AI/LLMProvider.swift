import Foundation

/// Entry point each provider must conform to.
protocol LLMProvider: AnyObject {
    var id: LLMProviderID { get }
    var displayName: String { get }

    /// Returns cached model descriptors or fetches remote list.
    func availableModels() async throws -> [LLMModelDescriptor]

    /// Ensures credentials/network reachability.
    func authenticate() async throws

    /// Performs a completion request with the given model.
    func send(request: LLMRequest, using model: LLMModelDescriptor) async throws -> LLMResponse
}

enum LLMProviderError: Error {
    case unauthenticated
    case unsupportedModel
}
