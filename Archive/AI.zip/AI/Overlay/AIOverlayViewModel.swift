import Foundation
import Combine

@MainActor
final class AIOverlayViewModel: ObservableObject {
    struct Message: Identifiable {
        enum Sender {
            case user
            case assistant
        }

        let id = UUID()
        let sender: Sender
        let text: String
        let timestamp = Date()
    }

    @Published private(set) var providerDisplayName: String = "No provider"
    @Published private(set) var statusText: String = "Awaiting connection"
    @Published var models: [LLMModelDescriptor] = []
    @Published var selectedModelID: String?
    @Published var history: [Message] = []
    @Published var isSending: Bool = false
    @Published var lastError: String?

    private var provider: LLMProvider?
    init() {
        loadProviders()
    }

    func loadProviders() {
        let providers = LLMProviderRegistry.shared.allProviders()
        provider = providers.first
        providerDisplayName = provider?.displayName ?? "No provider"
        if provider == nil {
            statusText = "No AI provider available"
        } else {
            Task {
                await refreshModels()
            }
        }
    }

    func refreshModels() async {
        guard let provider else {
            statusText = "No provider configured"
            return
        }
        statusText = "Connecting to \(provider.displayName)…"
        do {
            try await provider.authenticate()
            let fetched = try await provider.availableModels()
            models = fetched
            if selectedModelID == nil {
                selectedModelID = fetched.first?.name
            } else if fetched.first(where: { $0.name == selectedModelID }) == nil {
                selectedModelID = fetched.first?.name
            }
            statusText = "Connected"
            lastError = nil
        } catch {
            statusText = "Connection failed"
            lastError = error.localizedDescription
        }
    }

    func selectModel(id: String) {
        selectedModelID = id
    }

    func send(prompt: String) async {
        let trimmed = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard let provider, let model = models.first(where: { $0.name == selectedModelID }) else {
            lastError = "No model selected."
            return
        }
        isSending = true
        history.append(Message(sender: .user, text: trimmed))
        do {
            var messages: [LLMRequest.Message] = [
                .init(role: .user, content: trimmed)
            ]
            let request = LLMRequest(
                messages: messages,
                temperature: 0.2,
                toolCallsAllowed: false
            )
            let response = try await provider.send(request: request, using: model)
            history.append(Message(sender: .assistant, text: response.text))
            lastError = nil
        } catch {
            history.append(Message(sender: .assistant, text: "Error: \(error.localizedDescription)"))
            lastError = error.localizedDescription
        }
        isSending = false
    }

    func clearHistory() {
        history.removeAll()
    }
}
