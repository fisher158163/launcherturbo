# AI Module (Archived)

This directory contains the experimental AI overlay and GitHub Copilot
integration for LaunchNext. The feature is currently paused and should be
treated as archival code; it may be excluded from the app target and the UI
entry points may be disabled.

## What this includes
- Overlay UI + view model
- Provider abstraction
- Copilot auth + API client
- Settings UI

## How to restore development
1. Restore sources to the app target (Xcode Target Membership) and ensure
   `LaunchNext/AIOverlayController.swift` is included.
2. Re-enable integration points in:
   - `LaunchNext/LaunchpadApp.swift` (provider registration + hotkey)
   - `LaunchNext/AppStore.swift` (AI toggle + overlay actions + hotkey handling)
   - `LaunchNext/SettingsView.swift` (AI settings section)
3. Remove any build exclusions (for example `EXCLUDED_SOURCE_FILE_NAMES`).
4. Build and run, then sign in to Copilot from the AI settings panel.
