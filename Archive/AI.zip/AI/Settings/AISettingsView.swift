import SwiftUI
import AppKit

struct AISettingsView: View {
    enum Section: String, CaseIterable, Identifiable {
        case provider
        case shortcuts

        var id: String { rawValue }

        var iconGradient: LinearGradient {
            switch self {
            case .provider:
                return LinearGradient(colors: [.purple, .pink], startPoint: .topLeading, endPoint: .bottomTrailing)
            case .shortcuts:
                return LinearGradient(colors: [.blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
        }

        var iconName: String {
            switch self {
            case .provider: return "sparkles"
            case .shortcuts: return "keyboard"
            }
        }

        var title: LocalizedStringKey {
            switch self {
            case .provider: return "AI Provider"
            case .shortcuts: return "Shortcuts"
            }
        }
    }

    @ObservedObject var appStore: AppStore
    @ObservedObject var viewModel: AIOverlayViewModel
    var onDismiss: () -> Void = {}
    @State private var selectedSection: Section = .provider
    @State private var capturingShortcut: Bool = false
    @State private var shortcutCaptureMonitor: Any?
    @State private var pendingShortcut: AppStore.HotKeyConfiguration?

    private enum CopilotLoginState: Equatable {
        case idle
        case requestingCode
        case awaitingUser
        case success
        case failure(String)
    }
    @State private var copilotLoginState: CopilotLoginState = .idle
    @State private var copilotDeviceCode: CopilotDeviceCode?
    @State private var copilotCredential: AuthCredential?
    @State private var copilotErrorMessage: String?
    @State private var copilotPollingTask: Task<Void, Never>?
    @State private var copilotCancellationToken: CancellationToken?

    var body: some View {
        ZStack(alignment: .topTrailing) {
            NavigationSplitView {
                sidebarList
            } detail: {
                detail(for: selectedSection)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.ultraThinMaterial)

            Button(action: onDismiss) {
                Image(systemName: "xmark")
                    .font(.title2.bold())
                    .foregroundStyle(.secondary)
                    .padding(8)
                    .background(
                        Circle()
                            .fill(.ultraThinMaterial)
                            .liquidGlass()
                    )
            }
            .buttonStyle(.plain)
            .padding(.top, 12)
            .padding(.trailing, 16)
        }
        .frame(minWidth: 820, minHeight: 640)
    }

    @ViewBuilder
    private func detail(for section: Section) -> some View {
        GeometryReader { proxy in
            ZStack(alignment: .top) {
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .frame(height: 140)
                    .mask(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(1),
                                Color.white.opacity(0)
                            ],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .allowsHitTesting(false)

                VStack(alignment: .leading, spacing: 16) {
                    Text(section.title)
                        .font(.title3.bold())

                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 24) {
                            sectionContent(for: section)
                            Spacer(minLength: 0)
                        }
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .scrollBounceBehavior(.basedOnSize)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .frame(width: proxy.size.width, height: proxy.size.height, alignment: .topLeading)
            }
            .background(.ultraThinMaterial)
        }
    }

    @ViewBuilder
    private func sectionContent(for section: Section) -> some View {
        switch section {
        case .provider:
            providerSettings
        case .shortcuts:
            shortcutSettings
        }
    }

    private var sidebarList: some View {
        List(selection: $selectedSection) {
            ForEach(Section.allCases) { section in
                HStack(spacing: 8) {
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(section.iconGradient)
                        .overlay {
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .fill(Color.black.opacity(0.06))
                                .blendMode(.multiply)
                        }
                        .overlay {
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [
                                            .white.opacity(0.45),
                                            .white.opacity(0.08),
                                            .clear
                                        ],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .blendMode(.screen)
                        }
                        .overlay {
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .stroke(.white.opacity(0.22), lineWidth: 0.5)
                                .blendMode(.screen)
                        }
                        .overlay(
                            Image(systemName: section.iconName)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.white)
                        )
                        .frame(width: 24, height: 24)
                        .liquidGlass()

                    Text(section.title)
                        .font(.callout.weight(.medium))
                }
                .padding(.vertical, 2)
                .tag(section)
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
        .background(.ultraThinMaterial)
        .navigationSplitViewColumnWidth(min: 180, ideal: 205, max: 250)
    }

    private var providerSettings: some View {
        VStack(alignment: .leading, spacing: 16) {
            Toggle(isOn: $appStore.isAIEnabled) {
                Text("Enable AI features")
                    .font(.headline)
            }
            .toggleStyle(.switch)

            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("GitHub Copilot")
                        .font(.title3.weight(.semibold))
                    Text(viewModel.statusText)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    Task { await viewModel.refreshModels() }
                } label: {
                    Label("Refresh", systemImage: "arrow.clockwise")
                }
                .disabled(viewModel.isSending)
            }
            .padding(.bottom, 8)

            if let error = viewModel.lastError {
                ScrollView {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(maxHeight: 120)
                .padding(12)
                .background(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.red.opacity(0.08))
                )
            }

            if viewModel.models.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView()
                    Text("Loading models…")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            } else {
                Picker("Default model", selection: Binding(get: {
                    viewModel.selectedModelID ?? ""
                }, set: { newValue in
                    guard !newValue.isEmpty else { return }
                    viewModel.selectModel(id: newValue)
                })) {
                    ForEach(viewModel.models, id: \.name) { model in
                        Text(model.displayName).tag(model.name)
                    }
                }
                .pickerStyle(.menu)
            }

            Divider()

            copilotSettingsCard

            VStack(alignment: .leading, spacing: 8) {
                Button {
                    if let url = URL(string: "https://github.com/settings/copilot") {
                        NSWorkspace.shared.open(url)
                    }
                } label: {
                    Label("Manage Copilot", systemImage: "link")
                }

                Button {
                    if let url = URL(string: "https://github.com/settings/connections/applications") {
                        NSWorkspace.shared.open(url)
                    }
                } label: {
                    Label("Authorized apps", systemImage: "shield")
                }
            }
        }
    }

    private var shortcutSettings: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Overlay Shortcut")
                .font(.title3.weight(.semibold))
            Text("Set the global hotkey to toggle the AI overlay.")
                .font(.footnote)
                .foregroundStyle(.secondary)

            HStack(spacing: 12) {
                Button {
                    if capturingShortcut {
                        stopShortcutCapture(cancel: true)
                    } else {
                        startShortcutCapture()
                    }
                } label: {
                    Text(capturingShortcut ? "Cancel" : "Set Shortcut")
                }
                .disabled(!appStore.isAIEnabled)

                Button("Save") {
                    savePendingShortcut()
                }
                .disabled(!(capturingShortcut && pendingShortcut != nil))

                Button("Clear") {
                    if capturingShortcut {
                        stopShortcutCapture(cancel: false)
                        pendingShortcut = nil
                    }
                    appStore.clearAIOverlayHotKey()
                }
                .disabled(!capturingShortcut && appStore.aiOverlayHotKey == nil)
            }

            Text(shortcutStatusText())
                .font(.callout)
                .foregroundStyle(.secondary)
        }
    }

    private var copilotSettingsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("GitHub Copilot", systemImage: "brain.head.profile")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Text(copilotStatusLabel)
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(copilotStatusColor.opacity(0.12), in: Capsule())
                    .foregroundStyle(copilotStatusColor)
            }

            if let credential = copilotCredential {
                Text("Signed in. Token renews automatically.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else {
                Text("Connect your GitHub Copilot subscription to use hosted models.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            if let deviceCode = copilotDeviceCode, copilotLoginState == .awaitingUser {
                VStack(alignment: .leading, spacing: 8) {
                    Text("1. Open \(deviceCode.verificationURL.absoluteString)")
                        .font(.footnote)
                    HStack(spacing: 8) {
                        Text(deviceCode.userCode)
                            .font(.system(.title3, design: .monospaced).weight(.semibold))
                            .padding(.vertical, 4)
                            .padding(.horizontal, 10)
                            .background(RoundedRectangle(cornerRadius: 8).fill(Color.secondary.opacity(0.15)))
                        Button(action: {
                            NSPasteboard.general.clearContents()
                            NSPasteboard.general.setString(deviceCode.userCode, forType: .string)
                        }) {
                            Label("Copy", systemImage: "doc.on.doc")
                        }
                    }
                    Text("Enter the code above to authorize LaunchNext.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if copilotLoginState == .requestingCode {
                ProgressView("Generating device code…")
                    .progressViewStyle(.linear)
            }

            if let error = copilotErrorMessage {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Last error")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.secondary)
                        Spacer()
                        Button {
                            NSPasteboard.general.clearContents()
                            NSPasteboard.general.setString(error, forType: .string)
                        } label: {
                            Label("Copy", systemImage: "doc.on.doc")
                        }
                        .buttonStyle(.bordered)
                        .font(.caption)
                    }

                    ScrollView {
                        Text(error)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .frame(maxHeight: 100)
                    .padding(10)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.red.opacity(0.08))
                    )
                }
            }

            HStack(spacing: 12) {
                Button {
                    startCopilotSignIn()
                } label: {
                    Label("Sign in", systemImage: "key.fill")
                }
                .disabled(!appStore.isAIEnabled || copilotLoginState == .requestingCode || copilotLoginState == .awaitingUser)

                if copilotLoginState == .awaitingUser {
                    Button("Cancel") {
                        cancelCopilotSignIn()
                    }
                }

                if copilotCredential != nil {
                    Button(role: .destructive) {
                        signOutOfCopilot()
                    } label: {
                        Text("Sign out")
                    }
                }
            }
            .buttonStyle(.bordered)
        }
        .padding(18)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color(nsColor: .quaternarySystemFill))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.white.opacity(0.08))
        )
        .disabled(!appStore.isAIEnabled)
        .onAppear {
            refreshCopilotCredential()
        }
    }

    // MARK: - Shortcut handling
    private static let modifierOnlyKeyCodes: Set<UInt16> = [55, 54, 58, 61, 56, 60, 59, 62, 57]

    private func startShortcutCapture() {
        stopShortcutCapture(cancel: false)
        pendingShortcut = nil
        capturingShortcut = true
        shortcutCaptureMonitor = NSEvent.addLocalMonitorForEvents(matching: [.keyDown]) { event in
            handleShortcutCapture(event: event)
        }
    }

    private func stopShortcutCapture(cancel: Bool) {
        if let monitor = shortcutCaptureMonitor {
            NSEvent.removeMonitor(monitor)
            shortcutCaptureMonitor = nil
        }
        if cancel {
            pendingShortcut = nil
            NSSound.beep()
        }
        capturingShortcut = false
    }

    private func handleShortcutCapture(event: NSEvent) -> NSEvent? {
        let normalizedFlags = event.modifierFlags.normalizedShortcutFlags

        if event.keyCode == 53 && normalizedFlags.isEmpty { // Esc
            stopShortcutCapture(cancel: true)
            return nil
        }

        guard !normalizedFlags.isEmpty, !Self.modifierOnlyKeyCodes.contains(event.keyCode) else {
            NSSound.beep()
            return nil
        }

        pendingShortcut = AppStore.HotKeyConfiguration(keyCode: event.keyCode, modifierFlags: normalizedFlags)
        return nil
    }

    private func savePendingShortcut() {
        guard let shortcut = pendingShortcut else { return }
        appStore.setAIOverlayHotKey(keyCode: shortcut.keyCode, modifierFlags: shortcut.modifierFlags)
        pendingShortcut = nil
        stopShortcutCapture(cancel: false)
    }

    private func shortcutStatusText() -> String {
        if capturingShortcut {
            if let shortcut = pendingShortcut {
                let base = shortcut.displayString
                if shortcut.modifierFlags.isEmpty {
                    return base + " • Add modifier"
                }
                return base
            }
            return "Press keys to set overlay shortcut…"
        }
        return appStore.aiOverlayHotKeyDisplayText(nonePlaceholder: "Not set")
    }

    // MARK: - Copilot auth
    private var copilotStatusLabel: String {
        if copilotCredential != nil || copilotLoginState == .success {
            return "Connected"
        }
        switch copilotLoginState {
        case .idle:
            return "Not connected"
        case .requestingCode:
            return "Authorizing…"
        case .awaitingUser:
            return "Awaiting confirmation"
        case .failure:
            return "Failed"
        case .success:
            return "Connected"
        }
    }

    private var copilotStatusColor: Color {
        if copilotCredential != nil || copilotLoginState == .success {
            return .green
        }
        switch copilotLoginState {
        case .failure:
            return .red
        case .requestingCode, .awaitingUser:
            return .orange
        default:
            return .secondary
        }
    }

    private func startCopilotSignIn() {
        guard appStore.isAIEnabled else { return }
        guard copilotLoginState != .requestingCode else { return }
        guard let manager = makeCopilotAuthManager() else {
            copilotErrorMessage = "Copilot auth unavailable."
            return
        }
        copilotErrorMessage = nil
        copilotLoginState = .requestingCode
        Task {
            do {
                let code = try await manager.startDeviceCodeFlow()
                await MainActor.run {
                    self.copilotDeviceCode = code
                    self.copilotLoginState = .awaitingUser
                    NSWorkspace.shared.open(code.verificationURL)
                    self.beginPollingForCopilot(code: code, manager: manager)
                }
            } catch {
                await MainActor.run {
                    self.copilotLoginState = .failure(error.localizedDescription)
                    self.copilotErrorMessage = error.localizedDescription
                }
            }
        }
    }

    @MainActor
    private func beginPollingForCopilot(code: CopilotDeviceCode, manager: CopilotAuthManager) {
        copilotCancellationToken?.cancel()
        copilotPollingTask?.cancel()
        let token = CancellationToken()
        copilotCancellationToken = token
        copilotPollingTask = Task {
            do {
                let oauthToken = try await manager.pollForOAuthToken(deviceCode: code, cancellationToken: token)
                let credential = try await manager.refreshAPIToken(using: oauthToken)
                await MainActor.run {
                    self.copilotCredential = credential
                    self.copilotDeviceCode = nil
                    self.copilotLoginState = .success
                    self.copilotErrorMessage = nil
                    self.copilotPollingTask = nil
                    Task { await viewModel.refreshModels() }
                }
            } catch {
                if Task.isCancelled { return }
                await MainActor.run {
                    self.copilotLoginState = .failure(error.localizedDescription)
                    self.copilotErrorMessage = error.localizedDescription
                    self.copilotPollingTask = nil
                }
            }
        }
    }

    private func cancelCopilotSignIn() {
        copilotCancellationToken?.cancel()
        copilotPollingTask?.cancel()
        copilotDeviceCode = nil
        copilotLoginState = .idle
        copilotErrorMessage = nil
    }

    private func signOutOfCopilot() {
        cancelCopilotSignIn()
        guard let store = AppDelegate.shared?.authStore else { return }
        try? store.removeCredential(for: LLMProviderID("github-copilot"))
        copilotCredential = nil
        copilotLoginState = .idle
    }

    private func refreshCopilotCredential() {
        guard let store = AppDelegate.shared?.authStore else { return }
        copilotCredential = store.credential(for: LLMProviderID("github-copilot"))
        if copilotCredential != nil {
            copilotLoginState = .success
        } else if case .success = copilotLoginState {
            copilotLoginState = .idle
        }
    }

    private func makeCopilotAuthManager() -> CopilotAuthManager? {
        guard let delegate = AppDelegate.shared else { return nil }
        return CopilotAuthManager(authStore: delegate.authStore)
    }
}
