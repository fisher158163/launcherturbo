import Foundation

/// Represents a unique provider identifier.
struct LLMProviderID: Hashable, Codable, CustomStringConvertible {
    let rawValue: String

    init(_ rawValue: String) {
        self.rawValue = rawValue
    }

    var description: String { rawValue }
}

/// Describes a language model exposed by a provider.
struct LLMModelDescriptor: Identifiable, Hashable, Codable {
    enum Capability: String, Codable {
        case vision
        case toolUse
        case reasoning
    }

    var id: String { name }
    let name: String
    let displayName: String
    let maxContextTokens: Int
    let capabilities: Set<Capability>
}

/// High-level request payload that providers can translate to their specific APIs.
struct LLMRequest {
    struct Message {
        enum Role {
            case system, user, assistant
        }

        let role: Role
        let content: String
    }

    let messages: [Message]
    let temperature: Double?
    let toolCallsAllowed: Bool

    init(messages: [Message],
         temperature: Double? = nil,
         toolCallsAllowed: Bool = false) {
        self.messages = messages
        self.temperature = temperature
        self.toolCallsAllowed = toolCallsAllowed
    }
}

/// Generic response object used by the UI layer.
struct LLMResponse {
    let text: String
    let finishReason: String?
}
