import SwiftUI
import AppKit
import QuartzCore

final class AIOverlayController: NSObject, NSWindowDelegate {
    static let shared = AIOverlayController()

    private var panel: AIOverlayWindow?
    private var hostingController: NSHostingController<AIOverlayView>?
    private var settingsPanel: NSWindow?

    private let defaultSize = NSSize(width: 560, height: 400)
    private let lastOriginDefaultsKey = "AIOverlayController.lastOrigin"
    private var pendingOriginSaveWorkItem: DispatchWorkItem?
    private var workspaceObserver: Any?

    private override init() {
        super.init()
        workspaceObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.syncPanelWithActiveSpace()
        }
    }

    deinit {
        if let observer = workspaceObserver {
            NSWorkspace.shared.notificationCenter.removeObserver(observer)
        }
    }

    func show(with appStore: AppStore) {
        if panel == nil {
            createWindow(with: appStore)
        } else {
            updateRootView(appStore: appStore)
        }
        guard let panel else { return }
        if !NSApp.isActive {
            if #available(macOS 14.0, *) {
                NSApp.activate()
            } else {
                NSApp.activate(ignoringOtherApps: true)
            }
        }
        positionWindowIfNeeded(panel)
        bringPanelToFront(panel)

        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.22
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            panel.animator().alphaValue = 1
        }
    }

    func hide() {
        guard let panel else { return }
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.18
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            panel.animator().alphaValue = 0
        } completionHandler: { [weak self] in
            panel.orderOut(nil)
            self?.panel?.alphaValue = 0
            self?.closeSettingsPanel()
        }
    }

    func toggle(with appStore: AppStore) {
        if isVisible {
            hide()
        } else {
            show(with: appStore)
        }
    }

    var isVisible: Bool {
        guard let panel else { return false }
        return panel.isVisible && panel.alphaValue > 0.01
    }

    private func createWindow(with appStore: AppStore) {
        let window = AIOverlayWindow(
            contentRect: NSRect(origin: .zero, size: defaultSize),
            styleMask: [.borderless, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        window.level = .floating
        window.collectionBehavior = [.transient, .moveToActiveSpace, .fullScreenAuxiliary, .ignoresCycle]
        window.backgroundColor = .clear
        window.isOpaque = false
        window.isMovableByWindowBackground = true
        window.ignoresMouseEvents = false
        window.hidesOnDeactivate = false
        window.hasShadow = false
        window.alphaValue = 0
        window.delegate = self

        let hosting = NSHostingController(rootView: AIOverlayView(appStore: appStore))
        hosting.view.wantsLayer = true
        hosting.view.layer?.masksToBounds = false

        window.contentViewController = hosting
        window.setFrame(NSRect(origin: .zero, size: defaultSize), display: false)

        hostingController = hosting
        panel = window
    }

    private func updateRootView(appStore: AppStore) {
        hostingController?.rootView = AIOverlayView(appStore: appStore)
    }

    func presentSettingsPanel(appStore: AppStore, viewModel: AIOverlayViewModel) {
        if let window = settingsPanel {
            NSApp.activate(ignoringOtherApps: true)
            window.makeKeyAndOrderFront(nil)
            return
        }

        let rect = NSRect(x: 0, y: 0, width: 820, height: 640)
        let panel = AISettingsPanel(
            contentRect: rect,
            styleMask: [.borderless, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        panel.backgroundColor = .clear
        panel.isOpaque = false
        panel.hasShadow = true
        panel.isMovableByWindowBackground = true
        panel.level = .floating
        panel.isReleasedWhenClosed = false
        panel.center()
        panel.delegate = self
        let hosting = NSHostingView(
            rootView: AISettingsView(appStore: appStore, viewModel: viewModel) { [weak self] in
                self?.closeSettingsPanel()
            }
        )
        hosting.wantsLayer = true
        hosting.layer?.cornerRadius = 12
        if #available(macOS 13.0, *) {
            hosting.layer?.cornerCurve = .continuous
        }
        hosting.layer?.masksToBounds = true
        hosting.frame = panel.contentView?.bounds ?? rect
        hosting.autoresizingMask = [.width, .height]
        panel.contentView = hosting

        settingsPanel = panel
        NSApp.activate(ignoringOtherApps: true)
        bringPanelToFront(panel)
    }

    private func positionWindowIfNeeded(_ window: NSWindow) {
        if let savedOrigin = loadSavedOrigin(),
           let adjusted = adjustedOrigin(savedOrigin, for: window.frame.size) {
            window.setFrameOrigin(adjusted)
            return
        }
        guard let screen = window.screen ?? NSScreen.main else { return }
        let visibleFrame = screen.visibleFrame
        let size = window.frame.size
        let origin = NSPoint(
            x: visibleFrame.midX - (size.width / 2),
            y: visibleFrame.midY - (size.height / 2)
        )
        window.setFrameOrigin(adjustedOrigin(origin, for: size) ?? origin)
    }

    private func loadSavedOrigin() -> NSPoint? {
        guard let raw = UserDefaults.standard.string(forKey: lastOriginDefaultsKey) else { return nil }
        return NSPointFromString(raw)
    }

    private func saveOrigin(_ origin: NSPoint) {
        UserDefaults.standard.set(NSStringFromPoint(origin), forKey: lastOriginDefaultsKey)
    }

    private func adjustedOrigin(_ origin: NSPoint, for size: NSSize) -> NSPoint? {
        let screens = NSScreen.screens
        for screen in screens {
            let visible = screen.visibleFrame
            if isRect(NSRect(origin: origin, size: size), containedIn: visible) {
                return origin
            }
        }
        guard let screen = NSScreen.main else { return nil }
        let visible = screen.visibleFrame
        let clampedX = min(max(origin.x, visible.minX), visible.maxX - size.width)
        let clampedY = min(max(origin.y, visible.minY), visible.maxY - size.height)
        if size.width > visible.width || size.height > visible.height {
            return nil
        }
        return NSPoint(x: clampedX, y: clampedY)
    }

    private func isRect(_ rect: NSRect, containedIn frame: NSRect) -> Bool {
        rect.minX >= frame.minX &&
        rect.maxX <= frame.maxX &&
        rect.minY >= frame.minY &&
        rect.maxY <= frame.maxY
    }

    private func scheduleSaveOrigin(for window: NSWindow) {
        pendingOriginSaveWorkItem?.cancel()
        let work = DispatchWorkItem { [weak self, weak window] in
            guard let self, let window else { return }
            self.saveOrigin(window.frame.origin)
        }
        pendingOriginSaveWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: work)
    }

    private func bringPanelToFront(_ panel: NSPanel) {
        guard panel.isOnActiveSpace else {
            let previousBehavior = panel.collectionBehavior
            panel.collectionBehavior.insert(.moveToActiveSpace)
            panel.orderFrontRegardless()
            panel.collectionBehavior = previousBehavior
            return
        }
        panel.makeKeyAndOrderFront(nil)
    }

    private func syncPanelWithActiveSpace() {
        guard let panel, panel.isVisible else { return }
        if !panel.isOnActiveSpace {
            bringPanelToFront(panel)
        }
    }

    func windowDidMove(_ notification: Notification) {
        guard let window = notification.object as? NSWindow, window == panel else { return }
        scheduleSaveOrigin(for: window)
    }

    func windowDidEndLiveResize(_ notification: Notification) {
        guard let window = notification.object as? NSWindow, window == panel else { return }
        scheduleSaveOrigin(for: window)
    }

    func windowWillClose(_ notification: Notification) {
        guard let window = notification.object as? NSWindow else { return }
        if window == settingsPanel {
            settingsPanel = nil
        }
    }

    private func closeSettingsPanel() {
        settingsPanel?.orderOut(nil)
        settingsPanel = nil
    }
}

final class AIOverlayWindow: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

final class AISettingsPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

struct AIOverlayView: View {
    @ObservedObject var appStore: AppStore
    @StateObject private var viewModel = AIOverlayViewModel()
    @State private var promptText: String = ""

    var body: some View {
        let containerShape = RoundedRectangle(cornerRadius: 28, style: .continuous)
        ZStack {
            backgroundLayer
            contentLayer
        }
        .frame(width: 560, height: 400)
        .clipShape(containerShape)
    }

    private var backgroundLayer: some View {
        let shape = RoundedRectangle(cornerRadius: 28, style: .continuous)
        return Group {
            if #available(macOS 26.0, iOS 18.0, *) {
                shape
                    .fill(Color.clear)
                    .glassEffect(.regular, in: shape)
                    .background(
                        shape
                            .fill(Color.black.opacity(0.22))
                    )
            } else {
                shape
                    .fill(Color.clear)
                    .background(.regularMaterial, in: shape)
                    .background(
                        shape
                            .fill(Color.black.opacity(0.22))
                    )
            }
        }
    }

    private var contentLayer: some View {
        VStack(alignment: .leading, spacing: 18) {
            headerView
            Divider().opacity(0.3)
            conversationView
            composerView
        }
        .padding(28)
        .foregroundStyle(Color.primary)
    }

    private var headerView: some View {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(viewModel.providerDisplayName)
                        .font(.title3.weight(.semibold))
                    Text(viewModel.statusText)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    AIOverlayController.shared.presentSettingsPanel(appStore: appStore, viewModel: viewModel)
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.title3.weight(.semibold))
                        .padding(10)
                        .background(.ultraThinMaterial, in: Circle())
                }
                .buttonStyle(.plain)
            }
    }

    private var conversationView: some View {
        ZStack(alignment: .topLeading) {
            if viewModel.history.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Ask Copilot about your Mac, apps, or workflows.")
                        .font(.headline)
                    Text("Responses appear here once you start a conversation.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(viewModel.history) { message in
                            HStack(alignment: .top, spacing: 10) {
                                Circle()
                                    .fill(message.sender == .user ? Color.accentColor : Color.pink.opacity(0.7))
                                    .frame(width: 28, height: 28)
                                    .overlay(
                                        Image(systemName: message.sender == .user ? "person.fill" : "sparkles")
                                            .font(.caption.weight(.bold))
                                            .foregroundStyle(.white)
                                    )
                                Text(message.text)
                                    .font(.body)
                                    .padding(12)
                                    .background(
                                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                                            .fill(message.sender == .user ? Color.accentColor.opacity(0.12) : Color.white.opacity(0.08))
                                    )
                                    .contextMenu {
                                        Button {
                                            NSPasteboard.general.clearContents()
                                            NSPasteboard.general.setString(message.text, forType: .string)
                                        } label: {
                                            Label("Copy", systemImage: "doc.on.doc")
                                        }
                                    }
                            }
                        }
                        if viewModel.isSending {
                            HStack(spacing: 8) {
                                ProgressView()
                                Text("Thinking…")
                                    .font(.footnote)
                            }
                            .padding(.leading, 38)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var composerView: some View {
        VStack(alignment: .leading, spacing: 12) {
            PromptTextView(text: $promptText,
                           isEditable: appStore.isAIEnabled && !viewModel.isSending) {
                submitPrompt()
            }
            .frame(minHeight: 80, maxHeight: 140)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.08))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Color.white.opacity(0.08))
            )

            HStack {
                Button {
                    promptText = ""
                    viewModel.clearHistory()
                } label: {
                    Label("Clear", systemImage: "trash")
                }
                .buttonStyle(.bordered)
                .disabled(viewModel.history.isEmpty)

                Spacer()

                Button {
                    submitPrompt()
                } label: {
                    Label("Send", systemImage: "paperplane.fill")
                }
                .buttonStyle(.borderedProminent)
                .tint(Color.accentColor)
                .disabled(viewModel.isSending || !appStore.isAIEnabled || promptText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
    }

    private func submitPrompt() {
        let text = promptText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !viewModel.isSending, appStore.isAIEnabled else { return }
        promptText = ""
        Task {
            await viewModel.send(prompt: text)
        }
    }

}
