import Foundation

final class CopilotProvider: LLMProvider {
    let id = LLMProviderID("github-copilot")
    let displayName = "GitHub Copilot"

    private let session: URLSession
    private let authManager: CopilotAuthManager
    private var cachedModels: [LLMModelDescriptor] = []
    private let cacheLock = NSLock()

    init(session: URLSession = .shared, authStore: AuthStoring) {
        self.session = session
        self.authManager = CopilotAuthManager(session: session, authStore: authStore)
    }

    func authenticate() async throws {
        _ = try await authManager.ensureValidSession()
    }

    func availableModels() async throws -> [LLMModelDescriptor] {
        cacheLock.lock()
        if !cachedModels.isEmpty {
            let models = cachedModels
            cacheLock.unlock()
            return models
        }
        cacheLock.unlock()

        let session = try await authManager.ensureValidSession()
        guard let modelsURL = apiURL(session.endpoint, path: "/models") else {
            throw CopilotAuthError.tokenExchangeFailed
        }

        var request = URLRequest(url: modelsURL)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        addCommonHeaders(to: &request, apiToken: session.apiToken)

        let (data, response) = try await self.session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw CopilotProviderError.invalidResponse
        }
        guard http.statusCode == 200 else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw CopilotProviderError.apiFailure(status: http.statusCode, body: body)
        }

        let payload: CopilotModelListPayload
        do {
            payload = try JSONDecoder().decode(CopilotModelListPayload.self, from: data)
        } catch {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw CopilotProviderError.decodingFailed(body)
        }
        let models = payload.data.compactMap { entry -> LLMModelDescriptor? in
            if let enabled = entry.model_picker_enabled, !enabled {
                return nil
            }
            let contextTokens = entry.capabilities?.limits?.max_context_window_tokens ?? 0
            return LLMModelDescriptor(
                name: entry.id,
                displayName: entry.display_name ?? entry.name ?? entry.id,
                maxContextTokens: contextTokens,
                capabilities: Set(capabilities(from: entry))
            )
        }

        cacheLock.lock()
        cachedModels = models
        cacheLock.unlock()
        return models
    }

    func send(request: LLMRequest, using model: LLMModelDescriptor) async throws -> LLMResponse {
        let session = try await authManager.ensureValidSession()
        guard let chatURL = apiURL(session.endpoint, path: "/chat/completions") else {
            throw CopilotAuthError.tokenExchangeFailed
        }

        let messages = request.messages.map { message -> [String: String] in
            let role: String
            switch message.role {
            case .system: role = "system"
            case .user: role = "user"
            case .assistant: role = "assistant"
            }
            return ["role": role, "content": message.content]
        }

        var urlRequest = URLRequest(url: chatURL)
        urlRequest.httpMethod = "POST"
        addCommonHeaders(to: &urlRequest, apiToken: session.apiToken)

        let body = CopilotChatPayload(
            intent: true,
            n: 1,
            stream: false,
            temperature: Float(request.temperature ?? 0.2),
            model: model.name,
            messages: messages
        )
        urlRequest.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await self.session.data(for: urlRequest)
        guard let http = response as? HTTPURLResponse else {
            throw CopilotProviderError.invalidResponse
        }
        guard http.statusCode == 200 else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw CopilotProviderError.apiFailure(status: http.statusCode, body: body)
        }

        let completion: CopilotChatCompletionPayload
        do {
            completion = try JSONDecoder().decode(CopilotChatCompletionPayload.self, from: data)
        } catch {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw CopilotProviderError.decodingFailed(body)
        }
        guard let choice = completion.choices.first else {
            throw CopilotProviderError.invalidResponse
        }
        let content = choice.message?.content ?? choice.delta?.content ?? ""

        return LLMResponse(text: content,
                           finishReason: choice.finish_reason)
    }

    private func capabilities(from model: CopilotModelDescriptor) -> [LLMModelDescriptor.Capability] {
        var caps: [LLMModelDescriptor.Capability] = []
        if model.capabilities?.supports?.tool_calls == true {
            caps.append(.toolUse)
        }
        if model.capabilities?.supports?.vision == true {
            caps.append(.vision)
        }
        if model.capabilities?.supports?.reasoning == true {
            caps.append(.reasoning)
        }
        return caps
    }

    private func addCommonHeaders(to request: inout URLRequest, apiToken: String) {
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiToken)", forHTTPHeaderField: "Authorization")
        request.setValue("vscode-chat", forHTTPHeaderField: "Copilot-Integration-Id")
        request.setValue(editorVersionHeader(), forHTTPHeaderField: "Editor-Version")
        request.setValue("launchnext-ai/0.1", forHTTPHeaderField: "Editor-Plugin-Version")
        request.setValue(UUID().uuidString, forHTTPHeaderField: "X-Request-Id")
        request.setValue("user", forHTTPHeaderField: "X-Initiator")
    }

    private func editorVersionHeader() -> String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"
        return "LaunchNext/\(version)"
    }

    private func apiURL(_ endpoint: String, path: String) -> URL? {
        var base = endpoint
        if base.hasSuffix("/") {
            base.removeLast()
        }
        return URL(string: base + path)
    }
}

// MARK: - DTOs

enum CopilotProviderError: Error, LocalizedError {
    case apiFailure(status: Int, body: String)
    case invalidResponse
    case decodingFailed(String)

    var errorDescription: String? {
        switch self {
        case .apiFailure(let status, let body):
            return "Copilot API error (\(status)): \(body)"
        case .invalidResponse:
            return "Received invalid response from Copilot."
        case .decodingFailed(let body):
            return "Could not decode Copilot response: \(body)"
        }
    }
}

private struct CopilotModelListPayload: Decodable {
    struct Entry: Decodable {
        struct Capabilities: Decodable {
            struct Limits: Decodable {
                let max_context_window_tokens: Int?
            }
            struct Supports: Decodable {
                let tool_calls: Bool?
                let streaming: Bool?
                let vision: Bool?
                let reasoning: Bool?
            }
            let limits: Limits?
            let supports: Supports?
        }

        let id: String
        let name: String?
        let display_name: String?
        let model_picker_enabled: Bool?
        let capabilities: Capabilities?
    }

    let data: [Entry]
}

private typealias CopilotModelDescriptor = CopilotModelListPayload.Entry

private struct CopilotChatPayload: Encodable {
    let intent: Bool
    let n: Int
    let stream: Bool
    let temperature: Float
    let model: String
    let messages: [[String: String]]
}

private struct CopilotChatCompletionPayload: Decodable {
    struct Choice: Decodable {
        struct MessageContent: Decodable {
            let role: String?
            let content: String?
        }

        let message: MessageContent?
        let delta: MessageContent?
        let finish_reason: String?
    }

    let choices: [Choice]
}
