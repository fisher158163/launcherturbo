import Foundation

enum CopilotAuthError: Error {
    case missingCredential
    case cancelled
    case tokenExchangeFailed
}

struct CopilotDeviceCode {
    let deviceCode: String
    let userCode: String
    let verificationURL: URL
    let interval: TimeInterval
    let expiresAt: Date
}

/// Handles GitHub device-code OAuth for Copilot.
final class CopilotAuthManager {
    private enum Constants {
        static let clientID = "Iv1.b507a08c87ecfe98"
        static let deviceCodeURL = URL(string: "https://github.com/login/device/code")!
        static let tokenURL = URL(string: "https://github.com/login/oauth/access_token")!
        static let copilotAPITokenURL = URL(string: "https://api.github.com/copilot_internal/v2/token")!
    }

    private let session: URLSession
    private let authStore: AuthStoring
    private let providerID = LLMProviderID("github-copilot")

    init(session: URLSession = .shared, authStore: AuthStoring) {
        self.session = session
        self.authStore = authStore
    }

    func currentCredential() -> AuthCredential? {
        authStore.credential(for: providerID)
    }

    /// Starts the device-code flow and returns the info needed for UI prompts.
    func startDeviceCodeFlow() async throws -> CopilotDeviceCode {
        var request = URLRequest(url: Constants.deviceCodeURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = formBody([
            "client_id": Constants.clientID,
            "scope": "read:user"
        ])

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw CopilotAuthError.tokenExchangeFailed
        }

        let payload = try JSONDecoder().decode(DeviceCodePayload.self, from: data)
        let expiresAt = Date().addingTimeInterval(TimeInterval(payload.expires_in))
        return CopilotDeviceCode(deviceCode: payload.device_code,
                                 userCode: payload.user_code,
                                 verificationURL: URL(string: payload.verification_uri) ?? Constants.deviceCodeURL,
                                 interval: TimeInterval(payload.interval),
                                 expiresAt: expiresAt)
    }

    /// Polls GitHub until an OAuth token is issued or the operation expires.
    func pollForOAuthToken(deviceCode: CopilotDeviceCode, cancellationToken: CancellationToken? = nil) async throws -> String {
        while Date() < deviceCode.expiresAt {
            if cancellationToken?.isCancelled == true {
                throw CopilotAuthError.cancelled
            }

            var request = URLRequest(url: Constants.tokenURL)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.httpBody = formBody([
                "client_id": Constants.clientID,
                "device_code": deviceCode.deviceCode,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code"
            ])

            let (data, _) = try await session.data(for: request)
            let response = try JSONDecoder().decode(TokenPollPayload.self, from: data)

            if let accessToken = response.access_token {
                return accessToken
            }

            if response.error == "slow_down" {
                try await Task.sleep(nanoseconds: UInt64(deviceCode.interval + 5) * 1_000_000_000)
            } else if response.error == "authorization_pending" {
                try await Task.sleep(nanoseconds: UInt64(deviceCode.interval) * 1_000_000_000)
            } else if let error = response.error {
                throw CopilotAuthError.tokenExchangeFailed
            } else {
                try await Task.sleep(nanoseconds: UInt64(deviceCode.interval) * 1_000_000_000)
            }
        }
        throw CopilotAuthError.tokenExchangeFailed
    }

    /// Exchanges the GitHub OAuth token for a short-lived Copilot API token.
    func refreshAPIToken(using oauthToken: String) async throws -> AuthCredential {
        var request = URLRequest(url: Constants.copilotAPITokenURL)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(oauthToken)", forHTTPHeaderField: "Authorization")
        request.setValue("GitHubCopilotChat/0.26.7", forHTTPHeaderField: "User-Agent")
        request.setValue("vscode/1.99.3", forHTTPHeaderField: "Editor-Version")
        request.setValue("copilot-chat/0.26.7", forHTTPHeaderField: "Editor-Plugin-Version")

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw CopilotAuthError.tokenExchangeFailed
        }

        let payload = try JSONDecoder().decode(CopilotTokenPayload.self, from: data)
        let expiresAt = Date(timeIntervalSince1970: payload.expires_at)
        let credential = AuthCredential.oauth(refresh: oauthToken,
                                              access: payload.token,
                                              expiresAt: expiresAt,
                                              endpoint: payload.endpoints.api)
        try authStore.save(credential, for: providerID)
        return credential
    }

    /// Ensures a valid Copilot API token is available.
    func ensureValidSession() async throws -> CopilotSession {
        if let credential = authStore.credential(for: providerID),
           case .oauth(let refresh, let access, let expiresAt, let endpoint) = credential {
            if let endpoint, expiresAt.timeIntervalSinceNow > 60 {
                return CopilotSession(apiToken: access,
                                      endpoint: endpoint,
                                      expiresAt: expiresAt,
                                      refreshToken: refresh)
            }
            let refreshed = try await refreshAPIToken(using: refresh)
            if case let .oauth(_, newAccess, newExpiry, newEndpoint) = refreshed,
               let endpoint = newEndpoint {
                return CopilotSession(apiToken: newAccess,
                                      endpoint: endpoint,
                                      expiresAt: newExpiry,
                                      refreshToken: refresh)
            }
        }
        throw CopilotAuthError.missingCredential
    }
}

// MARK: - DTOs

private struct DeviceCodePayload: Decodable {
    let device_code: String
    let user_code: String
    let verification_uri: String
    let expires_in: Int
    let interval: Int
}

private struct TokenPollPayload: Decodable {
    let access_token: String?
    let error: String?
}

private struct CopilotTokenPayload: Decodable {
    let token: String
    let expires_at: TimeInterval
    let endpoints: EndpointPayload

    struct EndpointPayload: Decodable {
        let api: String
    }
}

// MARK: - Cancellation helper

final class CancellationToken {
    private(set) var isCancelled = false
    func cancel() { isCancelled = true }
}

private func formBody(_ parameters: [String: String]) -> Data? {
    var components = URLComponents()
    components.queryItems = parameters.map { URLQueryItem(name: $0.key, value: $0.value) }
    return components.percentEncodedQuery?.data(using: .utf8)
}
struct CopilotSession {
    let apiToken: String
    let endpoint: String
    let expiresAt: Date
    let refreshToken: String
}
