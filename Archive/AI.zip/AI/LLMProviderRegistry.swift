import Foundation

/// Manages the lifecycle of all configured providers.
final class LLMProviderRegistry {
    static let shared = LLMProviderRegistry()

    private var providers: [LLMProviderID: LLMProvider] = [:]
    private let lock = NSLock()

    private init() {}

    func register(provider: LLMProvider) {
        lock.lock()
        providers[provider.id] = provider
        lock.unlock()
    }

    func provider(for id: LLMProviderID) -> LLMProvider? {
        lock.lock()
        defer { lock.unlock() }
        return providers[id]
    }

    func allProviders() -> [LLMProvider] {
        lock.lock()
        defer { lock.unlock() }
        return Array(providers.values)
    }
}
